# Profile card

A Pen created on CodePen.io. Original URL: [https://codepen.io/_Sabine/pen/xmyjeG](https://codepen.io/_Sabine/pen/xmyjeG).

100dayscss #006
#Profile card
Profile card ui design, sequenced animation, infinite chill wave svg animation based on @winkerVSbecks 's work & hover underline effect from @IanLunn
Plus, a cat picture because it's always appreciated ^^